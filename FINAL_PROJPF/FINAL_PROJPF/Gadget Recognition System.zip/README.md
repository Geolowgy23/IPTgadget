# Gadget Recognition System

## Project Members
- Member 1: Joey Ara Teh
- Member 2: Jomar Lorigas
